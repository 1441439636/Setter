create view ORDERS_VIEW as
select "ORDER_NUM","ORDER_DATE","CUST_ID" from ORDERS
